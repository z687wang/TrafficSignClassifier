# **Traffic Sign Classification** 
---
## Main Pipline
* Load the data set
* Explore, summarize and visualize the data set
* Design, train and test a model architecture
* Use the model to make predictions on new images
* Analyze the softmax probabilities of the new images
* Summarize the results with a written report


[//]: # (Image References)

[image1]: ./assets/data_visual_1.png "Train Data"
[image2]: ./assets/data_visual_2.png "Validation Data"
[image3]: ./assets/data_visual_3.png "Test Data"
[image4]: ./assets/original.png "Before any preprocess"
[image5]: ./assets/after_process.png "After preprocess"
[image6]: ./assets/augment.png "Traffic Sign 3"
[image7]: ./examples/placeholder.png "Traffic Sign 4"
[image8]: ./examples/placeholder.png "Traffic Sign 5"

### Data Set Summary & Exploration

#### 1. Provide a basic summary of the data set.

* The size of training set is 34799
* The size of the validation set is 4410
* The size of test set is 12630
* The shape of a traffic sign image is (32, 32, 3)
* The number of unique classes/labels in the data set is 43

#### 2. Include an exploratory visualization of the dataset.

Here is an exploratory visualization of the data set. It is a bar chart showing how the data

![alt text][image1]

![alt text][image2]

![alt text][image3]

### Design and Test a Model Architecture

#### 1. Image Preprocessing
Convert Image to Greyscale to reduce number of params for neutral network

Normalize Image to reduces the complexity of the problem

Here is an example of a traffic sign image before and after preprocessing

Before:

![alt text][image4]

After:

![alt text][image5]	

I decided to generate additional data because it can prevent model from overfitting

To add more data to the the data set, I used the following techniques:

translate rotate shear blur gamma flip pad random_scale linear contrast

Here is an example of an original image and an augmented image:

![alt text][image6]



#### Model Architecture

My final model consisted of the following layers:

| Layer         		|     Description	        					| 
|:---------------------:|:---------------------------------------------:| 
| Input         		| 32x32x1 Greyscale image   							| 
| Convolution 5x5     	| 1x1 stride, VALID padding, outputs 28x28x6 |
| RELU					|												|
| Max pooling	      	| 2x2 stride,  outputs 14x14x6 				|
| Convolution 5x5	    | 1x1 stride, VALID padding, outputs 10x10x16      									|
| RELU					|												|
| Max pooling	      	| 2x2 stride,  outputs 5x5x16 				|
| Convolution 5x5	    | 1x1 stride, VALID padding, outputs 1x1x412      									|
| Fully connected		| Input: 412 Output: 122        									|
| RELU					|												|
| Fully connected		| Input: 122 Output: 84        									|
| RELU					|												|
| Fully connected		| Input: 84 Output: 43        									|
| Softmax				|        Output									|
 


#### Training

Opitmizer: AdamOptimizer

Epochs = 227

Batch Size = 156

Learning Rate = 0.001

#### My final model results were:
* training set accuracy of .996
* validation set accuracy of .942
* test set accuracy of .943


### Test a Model on New Images
Included in jupyter notebook